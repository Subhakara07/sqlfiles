
 col osuser for a10;
 col username for a10;
 
 alter session set nls_date_format="yyyy-mm-dd hh24:mi:ss";
 
 col username for a10;
 col machine for a30;
 col program for a35;
 col osuser for a15;
 col module for a20;
 

select inst_id,sid,serial#,username,osuser,sql_id,machine,terminal,logon_time,status,osuser,module from gv$session where status='INACTIVE'  order by logon_time;

select tzn.tzabbrev, tzname, tz_offset(tzname) from V$TIMEZONE_NAMES tzn;


select sid,serial#,username,sql_id,machine,logon_time,status from gv$session where status='INACTIVE' and username='GDA' order by logon_time;


select username,MACHINE,count(*) from gv$session  where status='INACTIVE' group by MACHINE,username order by 3 desc;

select sql_id,count(*) from gv$session  group by sql_id


select sql_id,count(*) from gv$sql  where sql_id='ad1hu07nx6zu1'  group by sql_id;

select inst_id,status,count(*)  from gv$session where  group by  inst_id,status order by 4;


 select 'exec rdsadmin.rdsadmin_util.kill(sid => ' || SID ||',serial =>' ||SERIAL# || ',method => ''IMMEDIATE'');' from  v$session where  sid in('26514') ;

 status='INACTIVE' and program='onevz-mtas-input-handler-service'
 
 select sid,serial#,username,sql_id,logon_time,service_name from gv$session where status='INACTIVE' and inst_id='3' and service_name='cst_batch_svc' order by logon_time desc;

select  'alter system kill session ''' || sid || ',' || serial# || ','||'@'|| INST_ID || ''' immediate;'  from gv$session where sql_id ='gvt62gvanpfh8'  order by logon_time desc;



select  'alter system kill session ''' || sid || ',' || serial# || ','||'@'|| INST_ID || ''' immediate;'  from gv$session where sql_id='8mbc8sdqj4fvr'   order by logon_time;

select sid,serial#,INST_ID  from gv$session where  sql_id  in('a7ktq51q0ugbd') order by logon_time ;

set lines 300 pages 999;
col USERNAME for a20;
col WAIT_CLASS for a30;
col EVENT for a30;

select  username,osuser,sql_id,module,WAIT_CLASS,EVENT from gv$session where nvl(username,'SYS') != 'SYS' and status = 'ACTIVE' and last_call_et > 10 order  by logon_time;



  select user_id, sql_id,module,machine from gv$active_session_history where  sql_Id  in('gpcty02uz6mww');
  
  select username,user_id from dba_users where user_id='131';




select 'exec rdsadmin.rdsadmin_util.kill( ' || sid ||',' ||  serial# || ');' ||chr(10) ||'-- '   || machine || '|' ||module || '|' || program ||chr(10) ||'-- sqlids: '   || sql_id  || '|' || prev_sql_id as dataline
from
(
select
        l.INST_ID,
        l.SID,
        s.serial#,
        s.username,
        s.machine,
        s.module,
        s.program,
        s.sql_id,
        s.prev_sql_id,
        l.TYPE,
        decode(l.lmode,0,'None',1,'Null',2,'Row-S',3,'Row-X',4,'Share',5,'S/Row-X',6,'Exclusive') lockheld,
        DECODE(REQUEST,0,'None',1,'Null',2,'Row-S',3,'Row-X',4,'Share', 5,'S/ROW',6,'Exclusive')REQUEST,
        CTIME timeheld ,
        decode(l.BLOCK,0,'No',1, 'Yes', 2, 'Yes') block,
        s.blocking_instance,
        s.blocking_session
from gv$lock l,
     gv$session s
where (l.ID1,l.ID2,l.TYPE) in
       (select ID1,ID2,TYPE
        from gv$lock where request>0)
 and l.sid=s.sid
 and l.inst_id=s.inst_id
 and s.username='APP_CXP'
order by l.id1, l.lmode desc, l.ctime desc
)
where block='Yes'
and timeheld >=5
/



 select 'exec rdsadmin.rdsadmin_util.kill(sid => ' || SID ||',serial =>' ||SERIAL# || ',method => ''IMMEDIATE'');' from v$session where sid in('20664');

DBA_BLOCKING_LOCKS

grep -i ORA-28112 /app/oracle/diag/rdbms/*/*/trace/*.trc

********* Blocking Sessions ************
col BLOCKING_USERNAME for a10;
col BLOCKED_USERNAME for a10;
col BLOCKING_SQL_ID for a15;	
col BLOCKED_WAIT_EVENT for a30;
	SELECT
    s_bl.sid AS "BLOCKING_SESSION",
    s_bl.username AS "BLOCKING_USERNAME",
    s_bl.sql_id AS "BLOCKING_SQL_ID",
    s_w.sid AS "BLOCKED_SESSION",
    s_w.serial# AS "BLOCKED_SERIAL#",
    s_w.username AS "BLOCKED_USERNAME",
    s_w.sql_id AS "BLOCKED_SQL_ID",
    s_w.seconds_in_wait / 60 AS "WAIT_TIME_MIN",
    s_w.event AS "BLOCKED_WAIT_EVENT"
FROM
    gv$session s_w
JOIN
    gv$session s_bl ON s_w.blocking_session = s_bl.sid AND s_w.blocking_instance = s_bl.inst_id
WHERE
    s_w.blocking_session IS NOT NULL
ORDER BY
    s_w.seconds_in_wait DESC;



col sess for a25;
 col MACHINE for a29;
 col LOCKED_OBJECT for a30;


SELECT DECODE(request,0,'Holder: ','Waiter: ') || gv$lock.sid sess, machine, 
do.object_name as locked_object,id1, id2, lmode, request, gv$lock.type
FROM gv$lock join gv$session on gv$lock.sid=gv$session.sid and gv$lock.inst_id=gv$session.inst_id
join gv$locked_object lo on gv$lock.SID = lo.SESSION_ID and gv$lock.inst_id=lo.inst_id
join dba_objects do on lo.OBJECT_ID = do.OBJECT_ID
WHERE (id1, id2, gv$lock.type) IN (
 SELECT id1, id2, type FROM gv$lock WHERE request>0)
ORDER BY id1, request;




select inst_id, sid, serial#, username, program, module, status, sql_id, event, BLOCKING_INSTANCE, BLOCKING_SESSION from gv$session where module like '%<queue_name>%' ;

col blocking_status for a100
select s1.inst_id,s2.inst_id,s1.username || '@' || s1.machine
|| ' ( SID=' || s1.sid || ' ) is blocking '
|| s2.username || '@' || s2.machine || ' ( SID=' || s2.sid || ' ) ' AS blocking_status
from gv$lock l1, gv$session s1, gv$lock l2, gv$session s2
where s1.sid=l1.sid and s2.sid=l2.sid and s1.inst_id=l1.inst_id and s2.inst_id=l2.inst_id
and l1.BLOCK=1 and l2.request > 0 and l1.id1 = l2.id1 and l2.id2 = l2.id2 order by s1.inst_id;


select inst_id, sid, serial#, username, program, module, status, sql_id, event, BLOCKING_INSTANCE,
 BLOCKING_SESSION from gv$session where module like '%POSDB_TPA_Q02%';
 
 
 
 ************************Lock**************************************8
 
 
select l.inst_id,
l.sid,
s.username,
l.type,
s.status,
decode(l.lmode,0,'Node',1,'Null',2,'Row-S',3,'Row-X',4,'Share',5,'S/Row-X',6,'Exclusive') lockheld,
decode(Request,0,'Node',1,'Null',2,'Row-S',3,'Row-X',4,'Share',5,'S/Row-X',6,'Exclusive') Request,
CTIME/60 Timeheld,
decode(block,0,'No',1,'Yes',2,'Yes')block,
s.blocking_instance,
s.blocking_session
from gv$lock l,
gv$session s
where
(l.ID1,l.ID2,l.type) in( select id1,id2,type from gv$lock where request>0)
and l.sid=s.sid
and l.inst_id=s.inst_id
order by l.id1,l.lmode,l.ctime desc; 
 
 
 
 
 select INST_ID, sid, user_name, sql_text from gv$open_cursor where inst_id=1 and sid=23239;
 
 
 ****************Blocking history *****************
 
 
 /* Formatted on 8/27/2025 3:14:42 PM (QP5 v5.388) */
  SELECT -- Blocker Details
         blocking_session_info.session_id
             AS blocker_sid,
         blocking_session_info.instance_number
             AS blocker_inst,
         blocking_user.username
             AS blocker_username,
         DBMS_LOB.SUBSTR (blocking_session_sql.sql_text, 1000, 1)
             AS blocker_sql_text,
         -- Blocked Session Details
         blocked_session_info.session_id
             AS blocked_sid,
         blocked_session_info.instance_number
             AS blocked_inst,
         blocked_user.username
             AS blocked_username,
         blocked_session_info.event
             AS blocked_event,
         blocked_session_info.sql_id
             AS blocked_sql_id,
         -- Time Metrics
         COUNT (*)
             AS total_samples,
         ROUND (COUNT (*) * 1, 2)
             AS approx_wait_time_seconds,
         MIN (blocked_session_info.sample_time)
             AS first_seen,
         MAX (blocked_session_info.sample_time)
             AS last_seen
    FROM dba_hist_active_sess_history blocked_session_info
         JOIN dba_users blocked_user
             ON blocked_session_info.user_id = blocked_user.user_id
         JOIN dba_hist_active_sess_history blocking_session_info
             ON     blocked_session_info.blocking_session =
                    blocking_session_info.session_id
                AND blocked_session_info.blocking_inst_id =
                    blocking_session_info.instance_number
                AND blocked_session_info.sample_id =
                    blocking_session_info.sample_id
         JOIN dba_users blocking_user
             ON blocking_session_info.user_id = blocking_user.user_id
         LEFT JOIN v$sql blocking_session_sql
             ON     blocking_session_info.sql_id = blocking_session_sql.sql_id
                AND blocking_session_info.dbid = blocking_session_sql.con_id
   WHERE     blocked_session_info.blocking_session IS NOT NULL
         AND blocked_session_info.event LIKE 'enq: TX%'
         AND blocked_session_info.sample_time > SYSDATE - INTERVAL '15' MINUTE
         AND blocked_session_info.session_state = 'WAITING'
GROUP BY blocking_session_info.session_id,
         blocking_session_info.instance_number,
         blocking_user.username,
         DBMS_LOB.SUBSTR (blocking_session_sql.sql_text, 1000, 1),
         blocked_session_info.session_id,
         blocked_session_info.instance_number,
         blocked_user.username,
         blocked_session_info.event,
         blocked_session_info.sql_id
ORDER BY total_samples DESC
   FETCH FIRST 20 ROWS ONLY
 
 
 
 
 *****************TOP sql 's**************
 
 
 WITH sql_class AS
(select sql_id, state, count(*) occur from 
  (select   sql_id
  ,  CASE  WHEN session_state = 'ON CPU' THEN 'CPU'       
           WHEN session_state = 'WAITING' AND wait_class IN ('User I/O') THEN 'IO'
           ELSE 'WAIT' END state            
    from gv$active_session_history             
    where   session_type IN ( 'FOREGROUND')        
    and sample_time  between trunc(sysdate,'MI') - :minutes/24/60 and trunc(sysdate,'MI') )
    group by sql_id, state),
     ranked_sqls AS 
(select SQL_ID,  sum(occur) sql_occur  , rank () over (order by sum(occur)desc) xrank
from sql_class           
group by sql_id )
select sc.sql_id, state, occur from sql_class sc, ranked_sqls rs
where rs.sql_id = sc.sql_id 
and rs.xrank <= :top_n 
order by xrank, sql_id, state
 

************SID with PID's**************
 col PROGRAM for a20;
col osuser for a10;
col STATUS for a10;
col LOGON_TIM for a15;
col MACHINE for a15;

 SELECT
   -- s.INST_ID,
    s.sid,
    s.serial#,
    s.username,
     s.osuser,
    s.machine,
    s.status,
	s.program,
    s.logon_time
FROM
    v$session s
JOIN
    v$process p ON s.paddr = p.addr
WHERE
    p.SOSID  in('960831');




SELECT SUM(value) AS sum, inst.inst_id
    FROM GV$sesstat,  GV$statname,  GV$INSTANCE inst
    WHERE name = 'session uga memory max'
    AND GV$sesstat.statistic#=GV$statname.statistic#
    AND GV$sesstat.inst_id=inst.inst_id
    AND GV$statname.inst_id=inst.inst_id
    GROUP BY inst.inst_id




SELECT
    SESSION_ID,
    sql_id,
    sql_exec_start,
    event,
    program,
    module,
    machine
FROM     dba_hist_active_sess_history
WHERE     sql_id = '4tjzs3jx707x4'
ORDER BY  sql_exec_start DESC;



SELECT
    s.sid,
    s.serial#,
    s.username,       -- Will usually be 'SYS' for background processes
    s.program,
    s.status,         -- Should be 'ACTIVE' if it's currently doing work/waiting
    s.state,          -- e.g., 'WAITING' or 'WAITED SHORT TIME'
    s.event,          -- What LGWR itself is waiting on
    s.seconds_in_wait,
    p.spid AS os_pid, -- Operating System Process ID
    p.pname AS process_name -- Process name (should be LGWR)
FROM
    V$SESSION s
JOIN
    V$PROCESS p ON s.paddr = p.addr
WHERE
    s.program LIKE '%(LGWR)%'
    OR p.pname = 'LGWR'; -- Use p.pname for a more direct check;
    --------------------------------
    SELECT
    s.sid,
    s.event,
    s.p1text, s.p1,
    s.p2text, s.p2,
    s.p3text, s.p3
FROM
    V$SESSION s
WHERE
    s.program LIKE '%(LGWR)%' AND s.status = 'ACTIVE';



SELECT
    SESSION_ID,
    sql_id,
    sql_exec_start,
     program,
    module,
    machine
FROM     dba_hist_active_sess_history
WHERE     sql_id = '613bu2jy7csnp'
ORDER BY  sql_exec_start DESC;



**************************




SELECT
    -- Blocking Session Details
    bl.sid AS blocking_sid,
    s_bl.username AS blocking_username,
    s_bl.osuser AS blocking_osuser,
    s_bl.sql_id AS blocking_sql_id,
    -- Blocked Session Details
    w.sid AS blocked_sid,
    s_w.username AS blocked_username,
    s_w.osuser AS blocked_osuser,
    s_w.sql_id AS blocked_sql_id
FROM
    gv$lock bl -- Blocking session's lock
JOIN
    gv$session s_bl ON bl.sid = s_bl.sid AND bl.inst_id = s_bl.inst_id
JOIN
    gv$lock w ON bl.id1 = w.id1 AND bl.id2 = w.id2 AND bl.type = w.type
JOIN
    gv$session s_w ON w.sid = s_w.sid AND w.inst_id = s_w.inst_id
WHERE
    bl.block = 1 
    AND w.request > 0 
    AND bl.sid != w.sid; 
	

col BLOCKING_USERNAME for a10;
col BLOCKED_USERNAME for a10;
col BLOCKING_SQL_ID for a15;	
col BLOCKED_WAIT_EVENT for a30;
	SELECT
    s_bl.sid AS "BLOCKING_SESSION",
    s_bl.username AS "BLOCKING_USERNAME",
    s_bl.sql_id AS "BLOCKING_SQL_ID",
    s_w.sid AS "BLOCKED_SESSION",
    s_w.serial# AS "BLOCKED_SERIAL#",
    s_w.username AS "BLOCKED_USERNAME",
    s_w.sql_id AS "BLOCKED_SQL_ID",
    s_w.seconds_in_wait / 60 AS "WAIT_TIME_MIN",
    s_w.event AS "BLOCKED_WAIT_EVENT"
FROM
    gv$session s_w
JOIN
    gv$session s_bl ON s_w.blocking_session = s_bl.sid AND s_w.blocking_instance = s_bl.inst_id
WHERE
    s_w.blocking_session IS NOT NULL
ORDER BY
    s_bl.sid, s_w.seconds_in_wait DESC;
	




SELECT
    TABLE_OWNER,
    table_name,
    inserts,
    updates,
    deletes,
    timestamp AS last_dml_timestamp,
    truncated,
    DROP_SEGMENTS
FROM dba_tab_modifications
WHERE TABLE_OWNER = 'ACSSPROD'
    AND table_name = 'WEB_ACCESS_SETTING';
	
	
	
	
	
	
	
	
	
	
	*****************session history
	
	
	
	SELECT
    TRUNC(h.sample_time, 'MI') AS "Sample Hour", -- Truncate to the hour
   -- h.program,
   -- h.machine,
    du.username AS "Username", -- Get username from user_id
    h.sql_id,
    COUNT(*) AS "Total Active Samples" -- Number of 1-second samples within that hour for the group
FROM
    dba_hist_active_sess_history h
JOIN
    dba_users du ON h.user_id = du.user_id -- Join to get username
WHERE
    h.sample_time BETWEEN TO_TIMESTAMP('2025-06-20 11:45:00', 'YYYY-MM-DD HH24:MI:SS') AND TO_TIMESTAMP('2025-06-20 12:30:00', 'YYYY-MM-DD HH24:MI:SS')
    AND h.session_type = 'FOREGROUND' -- Focus on user sessions
    AND h.user_id NOT IN (0, 29) -- Exclude SYS and other common background/internal users (e.g., 29 for AUDSYS in 12c+)
GROUP BY
    TRUNC(h.sample_time, 'MI'), -- Group by the hour
    --h.program,
    --h.machine,
    du.username,
    h.sql_id
ORDER BY
    TRUNC(h.sample_time, 'MI') ASC; 
	
	
	
****************EVENT details**********
col sample_time for a25;
col WAIT_CLASS for a15;
col username for a12;
col EVENT for a30;
col s.sql_id for a20;

SELECT
  ash.sample_time,
   -- s.sid,
   -- s.serial#,
    s.username,
	s.sql_id,
   -- s.program,
  --  s.module,
  --  s.action,
    ash.event,
 --   ash.wait_class,
    COUNT(*) AS total_samples,
 --   SUM(ash.wait_time) AS total_wait_time_us, -- in microseconds
    SUM(CASE WHEN ash.session_state = 'WAITING' THEN ash.time_waited ELSE 0 END) AS total_active_wait_time_us
FROM
    v$active_session_history ash
JOIN
    v$session s ON ash.session_id = s.sid AND ash.session_serial# = s.serial#
WHERE
    -- ash.sample_time BETWEEN TO_TIMESTAMP('2025-06-20 11:45:00', 'YYYY-MM-DD HH24:MI:SS') AND TO_TIMESTAMP('2025-06-20 12:30:00', 'YYYY-MM-DD HH24:MI:SS')
   ash.sample_time BETWEEN SYSDATE - INTERVAL '2' HOUR AND SYSDATE
    AND ash.session_state = 'WAITING' -- Focus on sessions that were actually waiting
    AND ash.wait_class <> 'Idle' -- Exclude idle wait events
GROUP BY
 ash.sample_time,
  --  s.sid,
   -- s.serial#,
    s.username,
	s.sql_id,
   -- s.program,
   -- s.module,
   -- s.action,
    ash.event
    --ash.wait_class
ORDER BY
     ash.sample_time DESC;	
	 
	 ******************************history of blocking sessions***************
	 
	 
	 SELECT
    ash.sample_time,
    ash.session_id AS blocked_sid,
    ash.session_serial# AS blocked_serial,
    u_blocked.username AS blocked_username,
    ash.program AS blocked_program,
    ash.module AS blocked_module,
    ash.event AS blocked_wait_event,
    ash.wait_class AS blocked_wait_class,
    ash.sql_id AS blocked_sql_id,
    ash.current_obj# AS blocked_obj_id,
    ash.blocking_session AS blocker_sid,
    ash.blocking_session_serial# AS blocker_serial,
    ash.blocking_inst_id AS blocker_inst_id,
    ash.blocking_session_status AS blocker_status,
    u_blocker.username AS blocker_username,
    blkr.program AS blocker_program,
    blkr.module AS blocker_module,
    blkr.sql_id AS blocker_sql_id,
    blkr.event AS blocker_wait_event
FROM
    dba_hist_active_sess_history ash
JOIN
    dba_users u_blocked ON ash.user_id = u_blocked.user_id
LEFT JOIN
    dba_hist_active_sess_history blkr ON ash.blocking_session = blkr.session_id
                                  AND ash.blocking_session_serial# = blkr.session_serial#
                                  AND ash.blocking_inst_id = blkr.instance_number
                                  AND ash.snap_id = blkr.snap_id -- Join on snap_id for AWR history
                                  AND ash.sample_time = blkr.sample_time -- Try to find blocker at same sample time
LEFT JOIN
    dba_users u_blocker ON blkr.user_id = u_blocker.user_id
WHERE
    ash.sample_time BETWEEN SYSDATE - INTERVAL '2' HOUR AND SYSDATE -- Adjust time window as needed
    AND ash.blocking_session IS NOT NULL
    AND ash.blocking_session_status = 'VALID'
   and ash.wait_class='Concurrency'
ORDER BY
    ash.sample_time DESC, blocked_sid;
	
	
	
	
	
	
	
	
	
	
	SELECT
    -- BLOCKED SESSION information
    s.INST_ID AS blocked_inst_id,
    s.SID AS blocked_sid,
    s.SERIAL# AS blocked_serial#,
    s.USERNAME AS blocked_username,
    s.MACHINE AS blocked_machine,
    s.PROGRAM AS blocked_program,
    s.EVENT AS blocked_wait_event,
    s.SECONDS_IN_WAIT AS blocked_wait_time_secs,
    s.STATE AS blocked_wait_state,
    s.SQL_ID AS blocked_sql_id,
    blocked_sql.SQL_FULLTEXT AS blocked_sql_text,
    -- BLOCKING SESSION information
    bs.INST_ID AS blocking_inst_id,
    bs.SID AS blocking_sid,
    bs.SERIAL# AS blocking_serial#,
    bs.USERNAME AS blocking_username,
    bs.MACHINE AS blocking_machine,
    bs.PROGRAM AS blocking_program,
    bs.EVENT AS blocking_wait_event,
    bs.SECONDS_IN_WAIT AS blocking_wait_time_secs,
    bs.STATE AS blocking_wait_state,
    bs.SQL_ID AS blocking_sql_id,
    blocking_sql.SQL_FULLTEXT AS blocking_sql_text,
    -- Lock details (if applicable, for more specific lock types)
    CASE
        WHEN s.LOCKWAIT IS NOT NULL THEN (SELECT o.OBJECT_NAME FROM GV$LOCKED_OBJECT lo JOIN DBA_OBJECTS o ON lo.OBJECT_ID = o.OBJECT_ID WHERE lo.SESSION_ID = s.SID AND lo.INST_ID = s.INST_ID AND ROWNUM = 1)
        ELSE NULL
    END AS locked_object_name
FROM
    GV$SESSION s -- Use GV$SESSION for RAC
JOIN
    GV$SESSION bs ON s.BLOCKING_SESSION = bs.SID
                 AND s.BLOCKING_INSTANCE = bs.INST_ID
LEFT JOIN -- Use LEFT JOIN here as a session might not always have current SQL in GV$SQL
    GV$SQL blocked_sql ON s.SQL_ID = blocked_sql.SQL_ID AND s.SQL_CHILD_NUMBER = blocked_sql.CHILD_NUMBER AND s.INST_ID = blocked_sql.INST_ID
LEFT JOIN
    GV$SQL blocking_sql ON bs.SQL_ID = blocking_sql.SQL_ID AND bs.SQL_CHILD_NUMBER = blocking_sql.CHILD_NUMBER AND bs.INST_ID = blocking_sql.INST_ID
WHERE
    s.BLOCKING_SESSION IS NOT NULL
    AND s.BLOCKING_SESSION_STATUS = 'VALID'
    AND s.STATUS = 'ACTIVE' -- Only show actively waiting blocked sessions
    AND s.TYPE = 'USER'
ORDER BY
    blocked_wait_time_secs DESC;
	
	
	
	********************************
	
	
	
	set timing off
set verify off
set feedback off

set lines 200 pages 1000
col dt form a20
col program form a40
col module form a40
col name form a20
col machine form a30

prompt &1
prompt &2


prompt Total Sessions between $1 and &2:

select to_char(sample_time, 'mm-dd-yyyy hh24:mi') as dt, count(*) as total
from v$active_session_history
where trunc(sample_time) = trunc(sysdate)
and session_type !='BACKGROUND'
---and to_char(sample_time, 'hh24:mi') >= '&1' --'08-23-2011 03:30'
---and to_char(sample_time, 'hh24:mi') <= '&2' --'08-23-2011 04:10'
group by to_char(sample_time, 'mm-dd-yyyy hh24:mi')
order by 1 ;



break on dt skip 1 on report
compute sum of total skip 1 on report

prompt Total Sessions by SQL_ID:

select to_char(sample_time, 'mm-dd-yyyy hh24:mi') as dt, sql_id, count(*) as total
from v$active_session_history
where trunc(sample_time) = trunc(sysdate)
and session_type !='BACKGROUND'
group by to_char(sample_time, 'mm-dd-yyyy hh24:mi') , sql_id
order by 3 desc ;


prompt Total Sessions by Event Type:
select to_char(sample_time, 'mm-dd-yyyy hh24:mi') as dt, event, count(*) as total
from v$active_session_history
where trunc(sample_time) = trunc(sysdate)
and session_type !='BACKGROUND'
and to_char(sample_time, 'hh24:mi') = '&1' --'08-23-2011 03:42'
group by to_char(sample_time, 'mm-dd-yyyy hh24:mi') , event
order by 3 desc ;


prompt Total Sessions by Lock:
select to_char(sample_time, 'mm-dd-yyyy hh24:mi') as dt, blocking_session_status, count(*) as total
from v$active_session_history
where trunc(sample_time) = trunc(sysdate)
and session_type !='BACKGROUND'
and to_char(sample_time, 'hh24:mi') = '&1' --'08-23-2011 03:42'
group by to_char(sample_time, 'mm-dd-yyyy hh24:mi') , blocking_session_status
order by 3 desc ;


prompt Total Sessions by Connection Type:
select to_char(a.sample_time, 'mm-dd-yyyy hh24:mi') as dt, a.program, a.module, b.name, a.machine, count(*) as total
from v$active_session_history a, dba_services b
where trunc(a.sample_time) = trunc(sysdate)
and a.service_hash = b.name_hash
--and a.session_type !='BACKGROUND'
--and to_char(a.sample_time, 'hh24:mi') = '&1' --'08-23-2011 03:42'
group by to_char(a.sample_time, 'mm-dd-yyyy hh24:mi') ,  a.program, a.module, b.name, a.machine
order by 6 desc ;





select 
to_char(a.sample_time, 'mm-dd-yyyy hh24:mi') Time , count(*)  Active_sessions
 from gv$active_session_history a
where a.sample_time> SYSDATE-INTERVAL '3' HOUR
and session_state='ON CPU'
group by to_char(a.sample_time, 'mm-dd-yyyy hh24:mi')  
order by 1 desc ;


select user_id,
to_char(a.sample_time, 'mm-dd-yyyy hh24:mi') Time , a.sql_id,event,session_state,count(*)  Active_sessions
 from gv$active_session_history a
where a.sample_time> SYSDATE-INTERVAL '1' HOUR
--and sql_id='1wvnps071r10b'
group by to_char(a.sample_time, 'mm-dd-yyyy hh24:mi'),a.sql_id,event,session_state,user_id 
order by 1 desc ;

select 
to_char(a.sample_time, 'mm-dd-yyyy hh24:mi') Time , count(*)  Active_sessions
 from gv$active_session_history a
where a.sample_time> SYSDATE-INTERVAL '7' HOUR
group by to_char(a.sample_time, 'mm-dd-yyyy hh24:mi')  
order by 1 desc ;

select sql_id,
round(sum(wait_time + time_waited) /1e6,2) As total_time_ses 
 from gv$active_session_history 
where sample_time> SYSDATE-INTERVAL '2' HOUR
group by sql_id
order by total_time_ses desc 
fetch first 10 rows only;


***************** SQL ID with CPU from sessions*********
select 
to_char(sample_time, 'mm-dd-yyyy hh24:mi') Time,
sql_id, event,session_state,
round(sum(wait_time + time_waited) /6e7,2) As total_time_ses 
 from gv$active_session_history 
where sample_time> SYSDATE-INTERVAL '5' HOUR 
and session_state='ON CPU'
--and EVENT='enq: TX - row lock contention'
group by sql_id, event,session_state,to_char(sample_time, 'mm-dd-yyyy hh24:mi')
order by total_time_ses,Time desc 
fetch first 10 rows only;



select to_char(a.sample_time, 'mm-dd-yyyy hh24:mi') as dt,a.sql_id, count(*) as total
from v$active_session_history a, dba_services b
where   a.service_hash = b.name_hash
--and a.machine='tdclpey2va233.tdc.vzwcorp.com'
--and a.session_type !='BACKGROUND'
and a.sql_id='6bp7twk3d8hqv'
group by to_char(a.sample_time, 'mm-dd-yyyy hh24:mi'),a.sql_id
order by 1 desc ;


Kishore Bora 7/2/2025 1:30 PM • ad1hu07nx6zu1

select ss.username, se.SID,ss.sql_id, VALUE/100 cpu_usage_seconds
from v$session ss, v$sesstat se, v$statname sn
where se.STATISTIC# = sn.STATISTIC#
and NAME like '%CPU used by this session%'
and se.SID = ss.SID
and ss.status='ACTIVE'
and ss.username is not null
order by VALUE desc;




col event for a20;
col WAIT_CLASS for a20;

select 
to_char(a.sample_time, 'mm-dd-yyyy hh24:mi') Time , SESSION_ID,sql_id,EVENT,WAIT_CLASS,BLOCKING_SESSION,BLOCKING_INST_ID,SQL_PLAN_HASH_VALUE,CURRENT_OBJ#
 from gv$active_session_history a
where a.sample_time> SYSDATE-INTERVAL '1' HOUR
and a.BLOCKING_SESSION_STATUS='VALID'
---group by to_char(a.sample_time, 'mm-dd-yyyy hh24:mi')  
--order by 1 desc ;





SELECT
    s.sid,
    s.serial#,
    s.username,
    s.status,
    s.logon_time,
    s.last_call_et AS last_call_seconds,
    s.sql_id,
    s.prev_sql_id,
   -- s.program,
  --  s.module,
   -- s.action,
    s.state,
    sq.sql_text
FROM
    v$session s
LEFT JOIN -- Use LEFT JOIN to ensure sessions without current SQL_ID are still shown
    v$sql sq ON s.sql_id = sq.sql_id
             AND s.sql_child_number = sq.child_number
WHERE
    s.status = 'ACTIVE'
    AND s.type != 'BACKGROUND' -- Exclude background processes
    AND s.username IS NOT NULL -- Exclude internal Oracle sessions if desired
ORDER BY
    s.last_call_et DESC;
	

	
	
	
	
	col username for a14
col machine for a21
col event for a21
col osuser for a14
col status for a12
Col blk_sess for a12
col service for a12
select sid, serial#,status,sql_id, username, osuser,machine,last_call_et , BLOCKING_INSTANCE || BLOCKING_SESSION BLK_SESS,
service_name service, seconds_in_wait waittime,event
from gV$SESSION where status = 'ACTIVE' and nvl(username,'SYS') <> 'SYS' 
and type <> 'BACKGROUND' and osuser not in ('codemgr')   order by username,sql_id;



select value * ($PROCCENT/100) from v\$parameter where name = 'processes';


select count(1) from gv\$session where nvl(username,'SYS') != 'SYS' and status = 'ACTIVE' and last_call_et > $SQLTHRESHOLD



****************Wait event between two snaps*********

SELECT
    
    ash.wait_class,
    ash.event,
    COUNT(*) AS total_samples
FROM
    dba_hist_active_sess_history ash
WHERE
    ash.dbid = (SELECT dbid FROM v$database)
    --AND ash.SAMPLE_TIME > SYSDATE-INTERVAL '2' HOUR
   AND ash.sample_time BETWEEN TO_TIMESTAMP('2025-11-01 23:00:00', 'YYYY-MM-DD HH24:MI:SS')
                         AND TO_TIMESTAMP('2025-11-02 04:00:00', 'YYYY-MM-DD HH24:MI:SS')
GROUP BY
    ash.wait_class, ash.event
ORDER BY
    total_samples DESC;
	
****************Wait event between two snaps with sql id*********	
SELECT
    ash.sql_id,
   -- hst.sql_text,
    ash.module,           -- Application module (if set by DBMS_APPLICATION_INFO)
    ash.action,           -- Application action (if set by DBMS_APPLICATION_INFO)
    ash.event,            -- The specific wait event
    ash.wait_class,       -- The wait class
    COUNT(*) AS total_samples,
    ROUND(COUNT(*) * 100 / (SUM(COUNT(*)) OVER()), 2) AS pct_of_total_samples
FROM
    dba_hist_active_sess_history ash
LEFT JOIN -- LEFT JOIN in case sql_text not found (though rare for active SQL)
    dba_hist_sqltext hst ON ash.sql_id = hst.sql_id AND ash.dbid = hst.dbid
WHERE
    ash.dbid = (SELECT dbid FROM v$database) -- Important for RAC/CDB
    AND ash.snap_id BETWEEN &begin_snap_id AND &end_snap_id -- Use snap IDs from Step 1
    -- OR filter by time range if you prefer:
    -- AND ash.sample_time BETWEEN TO_TIMESTAMP('2025-07-24 14:00:00', 'YYYY-MM-DD HH24:MI:SS')
    --                     AND TO_TIMESTAMP('2025-07-24 16:00:00', 'YYYY-MM-DD HH24:MI:SS')
    AND ash.event IN (
        'buffer busy waits',
        'log file sync',
        'gc buffer busy release',
        'latch: ges resource hash list',
        'row cache lock'
    )
GROUP BY
    ash.sql_id,
    --hst.sql_text,
    ash.module,
    ash.action,
    ash.event,
    ash.wait_class
ORDER BY
    total_samples DESC;	
	
	
	SELECT
    ash.sql_id,
    --hst.sql_text,
    ash.event,
    ash.current_obj#,
    do.owner AS object_owner,
    do.object_name,
    do.object_type,
    ash.p1 AS file_id,
    ash.p2 AS block_id,
    COUNT(*) AS total_samples
FROM
    dba_hist_active_sess_history ash
LEFT JOIN
    dba_hist_sqltext hst ON ash.sql_id = hst.sql_id AND ash.dbid = hst.dbid
LEFT JOIN
    dba_objects do ON ash.current_obj# = do.object_id AND ash.dbid = do.data_object_id -- Note: data_object_id for segments
WHERE
    ash.dbid = (SELECT dbid FROM v$database)
    --AND ash.snap_id BETWEEN &begin_snap_id AND &end_snap_id
  --  AND ash.event IN ('buffer busy waits', 'gc buffer busy release')
    AND ash.current_obj# IS NOT NULL -- Focus on waits associated with an object
GROUP BY
    ash.sql_id,  ash.event, ash.current_obj#, do.owner, do.object_name, do.object_type, ash.p1, ash.p2
ORDER BY
    total_samples DESC;
	
	
	
	
	
set linesize 260
set time on
set timing on
set pause on
set pages 1000

col inst_id for 9999999 hea 'INST ID'
col osuser for a10 trunc
col sid for 9999
col serial# for 999999
col username for a20
col sql_id for a15
col event for a30 trunc
col machine for a30 trunc
col runt for a10
col last_call_et for 999999999999
col state for a7
col program for a20 trunc hea 'PROGRAM'
select
ses.inst_id,
osuser,
sid,
serial#,
USERNAME,
ses.sql_id,
event,
machine,
program,
decode(state,'WAITING','IN WAIT','ON CPU') STATE,
wait_time_micro / 1000 wtm,
ltrim(to_char(floor(SES.LAST_CALL_ET/3600), '09')) || ':'
|| ltrim(to_char(floor(mod(SES.LAST_CALL_ET, 3600)/60), '09')) || ':'
|| ltrim(to_char(mod(SES.LAST_CALL_ET, 60), '09')) RUNT,
last_call_et
FROM gV$SESSION SES
where SES.STATUS = 'ACTIVE'
and Ses.AUDSID <> userenv('SESSIONID')
--and username != 'SYS'  and SERVICE_NAME <> 'SYS$BACKGROUND'
--and type !='BACKGROUND'
order by last_call_et desc;




**************************************


SELECT /*+ RULE */ DISTINCT
                       a.inst_id,
                       a.sid,
                       a.serial#
                           AS serial1,
                       (SELECT aa.instance_name FROM gv$instance aa where aa.inst_id = a.inst_id)
                           AS instance_name,
                       a.username,
                       a.machine,
                       a.status,
                       a.last_call_et,
                       ROUND ((SYSDATE - a.logon_time) * 24 * 60)
                           AS log_on_min,
                       a.sql_id,
                       UPPER (TRIM (SUBSTR (b.sql_text, 1, 20))),
                       b.sql_text
                  FROM gv$session  a
                       JOIN gv$sql b
                           ON (    a.inst_id = b.inst_id
                               AND a.sql_id = b.sql_id
                               AND a.sql_address = b.address
                               AND a.sql_hash_value = b.hash_value
                               AND a.sql_child_number = b.child_number)
                 WHERE     a.status = 'ACTIVE'
                       AND a.sql_id IS NOT NULL
                       --AND a.username = 'APP_CXP'
                       AND a.last_call_et > 20
                       AND a.username NOT IN ('NEWRELIC_USER',
                                              'DBSNMP',
                                              'SYS',
                                              'INFRASTRUCTURE',
                                              'SYSTEM',
                                              'APEX_030200',
                                              'IAASADMIN',
                                              'APEX_PUBLIC_USER',
                                              'CTXSYS',
                                              'EXFSYS',
                                              'EXPUSR',
                                              'MDDATA',
                                              'MDSYS',
                                              'MGMT_VIEW',
                                              'OLAPSYS',
                                              'ORDDATA',
                                              'ORDPLUGINS',
                                              'ORDSYS',
                                              'OUTLN',
                                              'OWBSYS',
                                              'OWBSYS_AUDIT',
                                              'SCOTT',
                                              'SECURITY',
                                              'SQLTXADMIN',
                                              'SYSMAN',
                                              'WMSYS',
                                              'XDB',
                                              'IAASDBA',
                                              'OPS$ORACLE',
                                              'IMPL_DBA',
                                              'DB_DEPLOY',
                                              'POSDBA',
                                              'VPD_ADMIN',
                                              'DBMAINT')
                       AND a.username NOT LIKE '%SPLEX%'
                       AND a.username NOT LIKE '%GG%'
                       AND a.username NOT LIKE '%RMAN%'
                       AND a.username NOT LIKE '%BATCH%'
                       AND a.username NOT LIKE '%ETL%'
                       AND a.username IS NOT NULL
                       AND UPPER (TRIM (SUBSTR (b.sql_text, 1, 20))) LIKE
                               '%SELECT%'
							   
							   
							   
							   
------------------------

SELECT /*+ RULE */ DISTINCT
            s1.inst_id,
            s1.sid,
            s1.serial# AS serial1,
            (
                SELECT
                    aa.instance_name
                FROM
                    gv$instance aa
                WHERE
                    aa.inst_id = s1.inst_id
            )  instance_name,
            s1.username  blocker,
            l1.type      lock_type,
            s1.username,
            s1.machine,
            s1.status,
            round(s1.last_call_et / 60) last_call_et,
            round((sysdate - s1.logon_time) * 24 * 60) AS log_on_min,
            s1.sql_id,
            (
                SELECT
                    sql_text
                FROM
                    gv$sql
                WHERE
                        sql_id = s1.sql_id
                    AND ROWNUM = 1
            )  AS sql_text
        FROM
            gv$lock    l1,
            gv$session s1,
            gv$lock    l2
        WHERE
                s1.sid = l1.sid
            AND l1.id1 = l2.id1
            AND l1.id2 = l2.id2
            AND l1.block > 0
            AND l2.request > 0
            AND l1.lmode > 1
            AND l1.ctime / 60 > 5
            AND s1.username NOT IN ( 'DBSNMP', 'SYSTEM', 'APEX_030200', 'APEX_PUBLIC_USER', 'CTXSYS',
                 'EXFSYS', 'EXPUSR', 'MDDATA', 'MDSYS', 'MGMT_VIEW',
                 'OLAPSYS', 'ORDDATA', 'ORDPLUGINS', 'ORDSYS', 'OUTLN',
                 'OWBSYS', 'OWBSYS_AUDIT', 'SCOTT', 'SECURITY', 'SQLTXADMIN',
                 'SYSMAN', 'NEWRELIC_USER', 'WMSYS', 'XDB' )
            AND s1.username NOT LIKE '%RMAN%'							   