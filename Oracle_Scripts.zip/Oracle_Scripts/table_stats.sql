select table_name,avg_row_len,round(((blocks*16/1024)),2)||'MB' "TOTAL_SIZE",
round((num_rows*avg_row_len/1024/1024),2)||'Mb' "ACTUAL_SIZE",
round(((blocks*16/1024)-(num_rows*avg_row_len/1024/1024)),2) ||'MB' "FRAGMENTED_SPACE",
(round(((blocks*16/1024)-(num_rows*avg_row_len/1024/1024)),2)/round(((blocks*16/1024)),2))*100 "percentage"
from all_tables WHERE table_name='API_PAYLOAD_COMP_RSLTS';

*******************************SEQUNCE*********************

SELECT owner,
       table_name,
       column_name,
       data_type,
       data_default,
       identity_column
  FROM dba_tab_columns
 WHERE table_name = 'URL_REFERENCE'
 
 
 



SET LINESIZE 300 VERIFY OFF

COLUMN owner FORMAT A15
COLUMN table_name FORMAT A25
COLUMN index_name FORMAT A30

SELECT owner,
       table_name,
       num_rows,
       blocks,
       empty_blocks,
       avg_space
       chain_cnt,
       avg_row_len,
       last_analyzed,status,
	   partitioned
FROM   dba_tables
WHERE  owner not in('SYS','SYSTEM')
--and table_name='OLION_RPT_TMP'
and last_analyzed <sysdate-365 and ;

pfs.process_dtl_log


SELECT index_name,
       blevel,
       leaf_blocks,
       distinct_keys,
       avg_leaf_blocks_per_key,
       avg_data_blocks_per_key,
       clustering_factor,
       num_rows,
       last_analyzed
FROM   dba_indexes
WHERE  table_owner = UPPER('&1')
AND    table_name  = UPPER('ERROR_LOG')
ORDER BY index_name;

COLUMN column_name FORMAT A30
COLUMN low_value FORMAT A40
COLUMN high_value FORMAT A40
COLUMN endpoint_actual_value FORMAT A30

SELECT column_id,
       column_name,
       num_distinct,
       avg_col_len,
       histogram,
       low_value,
       high_value
FROM   dba_tab_columns
WHERE  owner       = UPPER('&1')
AND    table_name  = UPPER('&2')
ORDER BY column_id;

SET VERIFY ON



COLUMN owner FORMAT A20
COLUMN table_name FORMAT A30
COLUMN index_name FORMAT A30


SELECT owner,
       table_name,
       num_rows,
       blocks,
       empty_blocks,
       avg_space
       chain_cnt,
       avg_row_len,
       last_analyzed
FROM   dba_tables
WHERE  table_name = 'ord_ln';


exec dbms_stats.gather_table_stats (ownname => 'CODE', TABNAME => 'OFFER',METHOD_OPT => 'FOR ALL COLUMNS SIZE AUTO', ESTIMATE_PERCENT => DBMS_STATS.AUTO_SAMPLE_SIZE, DEGREE=> 32, CASCADE => TRUE, GRANULARITY => 'ALL');


EXECUTE DBMS_STATS.GATHER_SCHEMA_STATS(OWNNAME => 'PFS',DEGREE => 8, ESTIMATE_PERCENT => DBMS_STATS.AUTO_SAMPLE_SIZE, GRANULARITY => 'ALL', METHOD_OPT => 'FOR ALL COLUMNS SIZE AUTO',cascade=>TRUE);

"SPLEX2056".SHAREPLEX_TRANS

EXECUTE DBMS_STATS.GATHER_TABLE_STATS(OWNNAME => 'SPLEX2056',TABNAME => 'SHAREPLEX_TRANS', DEGREE => 8, ESTIMATE_PERCENT => DBMS_STATS.AUTO_SAMPLE_SIZE,cascade=>TRUE);



SELECT  'EXECUTE DBMS_STATS.GATHER_TABLE_STATS(OWNNAME => '''||owner||''', TABNAME => '''||table_name|| ''', ESTIMATE_PERCENT => DBMS_STATS.AUTO_SAMPLE_SIZE,cascade=>TRUE);'
FROM   dba_tables
WHERE  owner not in('SYS','SYSTEM')
and owner='CODE'
and table_name='OFFERTRACKING'
and last_analyzed <sysdate-365 order by avg_row_len desc;



	col OWNER for a10;
col TABLE_NAME for a25;
 col TABLESPACE_NAME for a15;
	SELECT
    s.owner,
    s.segment_name AS table_name,
    s.segment_type,
    s.tablespace_name,
    SUM(s.bytes) / 1024 / 1024 AS allocated_mb,
    SUM(s.bytes) / 1024 / 1024 / 1024 AS allocated_gb
FROM
    dba_segments s
WHERE
    s.segment_type IN ('TABLE', 'TABLE PARTITION', 'TABLE SUBPARTITION', 'LOBSEGMENT', 'LOB PARTITION')
   AND s.segment_name IN ( 'WHCTI_REP_AGENT_CTI_EVENT')
GROUP BY
    s.owner, s.segment_name, s.segment_type, s.tablespace_name
ORDER BY
    allocated_mb DESC;


select last_analyzed, stale_stats from dba_tab_statistics where table_name = 'ERROR_LOG';



SELECT
    TABLE_NAME,
    PARTITION_NAME,
    HIGH_VALUE,         -- For range partitions, the upper bound
    NUM_ROWS,           -- Number of rows in the partition
    LAST_ANALYZED,      -- When statistics were last gathered for the partition
    BLOCKS,             -- Number of blocks used by the partition
    SAMPLE_SIZE         -- Sample size used for statistics gathering
FROM
    dba_TAB_PARTITIONS
WHERE
     PARTITION_NAME = 'WRI$_OPTSTAT_SYNOPSIS$' -- Replace with your partition table name
ORDER BY
    PARTITION_POSITION;


col OWNER for a20;
 col OBJECT_NAME for a20;

SELECT
    t.owner,
    t.object_name,
    t.object_type,
    dts.num_rows,
    dts.avg_row_len,
    dts.last_analyzed,
    dts.stale_stats
FROM
    (SELECT DISTINCT
            o.owner,
            o.object_name,
            o.object_type
        FROM
            gv$sql_plan p
        JOIN
            all_objects o ON p.object_owner = o.owner AND p.object_name = o.object_name
        WHERE
            p.sql_id = '3r2yv6yk13mw8' 
            AND o.object_type IN ('TABLE', 'VIEW', 'MATERIALIZED VIEW') 
 ) t
LEFT JOIN
    dba_tab_statistics dts ON t.owner = dts.owner AND t.object_name = dts.table_name
ORDER BY
    t.owner, t.object_name;



SELECT COUNT(*) AS exact_row_count FROM CTIPROD.WHCTI_REP_AGENT_CTI_EVENT PARTITION SYS_P50451;



SET LINESIZE 150
COLUMN TABLE_OWNER FORMAT A15
COLUMN TABLE_NAME FORMAT A25
COLUMN PARTITION_NAME FORMAT A25
COLUMN SUBPARTITION_NAME FORMAT A25

SELECT
    dts.TABLE_OWNER,
    dts.TABLE_NAME,
    dts.PARTITION_NAME,
    dts.SUBPARTITION_NAME,
    dts.NUM_ROWS, -- Number of rows in the subpartition
    TO_CHAR(dts.LAST_ANALYZED, 'YYYY-MM-DD HH24:MI:SS') AS LAST_ANALYZED_DATE
FROM
    DBA_TAB_SUBPARTITIONS dts
WHERE
    dts.TABLE_OWNER = 'CTIPROD'
    AND dts.TABLE_NAME = 'WHCTI_REP_AGENT_CTI_EVENT'
    AND dts.SUBPARTITION_NAME = 'YOUR_SUBPARTITION_NAME'; -- Replace with the specific subpartition name
	
	
	
	SELECT
    p.table_owner AS TABLE_OWNER,
    p.table_name AS TABLE_NAME,
    p.partition_name AS PARTITION_NAME,
    TO_CHAR(p.last_analyzed, 'YYYY-MM-DD HH24:MI:SS') AS LAST_ANALYZED,
    p.num_rows AS PARTITION_NUM_ROWS,
    p.sample_size AS PARTITION_SAMPLE_SIZE,
    p.global_stats AS GLOBAL_STATS_FLAG -- YES if partition stats are based on global table stats
FROM
    dba_tab_partitions p
WHERE p.table_name = 'VZ_VZCM_WORK_PROMON'
ORDER BY
    p.table_owner, p.table_name, p.partition_position;
	
	
	
	
	SELECT
    owner,
    index_name,
    table_name,
    status,        -- VALID, UNUSABLE, N/A (for partitioned)
    index_type,    -- NORMAL, BITMAP, FUNCTION-BASED NORMAL, etc.
    partitioned    -- YES/NO
FROM
    dba_indexes
WHERE 
    table_name='VZ_VZCM_WORK_PROMON'
ORDER BY
    owner, table_name, index_name;
	
	
	SELECT
    owner,
    index_name,
    partition_name,
    status, -- VALID, UNUSABLE
    last_analyzed,
    num_rows
FROM
    dba_ind_partitions
WHERE
     partition_name in select PARTITION_NAME from dba_i
ORDER Bta
    owner, index_name, partition_position;
	
	
	SET LINESIZE 200
SET PAGESIZE 50
COLUMN TABLE_OWNER FORMAT A15
COLUMN TABLE_NAME FORMAT A30
COLUMN PARTITION_NAME FORMAT A30
COLUMN INDEX_NAME FORMAT A30
COLUMN INDEX_STATUS FORMAT A10
COLUMN STALE_STATS FORMAT A10

SELECT
    p.table_owner AS TABLE_OWNER,
    p.table_name AS TABLE_NAME,
    p.partition_name AS PARTITION_NAME,
    i.index_name AS INDEX_NAME,
    i.status AS INDEX_STATUS
	FROM
    all_tab_partitions p
JOIN
    all_indexes i ON p.table_owner = i.table_owner
                    AND p.table_name = i.table_name
WHERE
    p.table_owner NOT IN ('SYS', 'SYSTEM', 'SYSMAN', 'DBSNMP', 'OUTLN', 'AUDSYS', 'XDB', 'WMSYS', 'APEX_040200', 'GSMADMIN_INTERNAL')
    AND i.partitioned = 'YES' -- Filter for partitioned indexes only
	and p.table_name='VZ_VZCM_WORK_PROMON'
ORDER BY
    p.table_owner, p.table_name, p.partition_name, i.index_name;